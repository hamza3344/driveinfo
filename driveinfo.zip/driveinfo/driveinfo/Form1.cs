﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;
using System.Management;

namespace driveinfo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //ram info
        [DllImport("Kernel32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool GetPhysicallyInstalledSystemMemory(out long totalmemory);
        private void Form1_Load(object sender, EventArgs e)
        {
            //hard drive info
            DriveInfo[] alldrives = DriveInfo.GetDrives();
            foreach(DriveInfo d in alldrives)
            {
                MessageBox.Show("Drive name " + d.Name + Environment.NewLine + "Drive Type" + d.DriveType);
                if(d.IsReady)
                {
                    MessageBox.Show(@"Volume label "+d.VolumeLabel+Environment.NewLine+
                        "File System"+d.DriveFormat+Environment.NewLine+
                        "Available space"+(d.AvailableFreeSpace/(1024*1024*1024))+" GB"+Environment.NewLine+
                        "Total size"+(d.TotalSize/(1024*1024*1024))+" GB");
                }
            }
            long kb;
            GetPhysicallyInstalledSystemMemory(out kb);
            MessageBox.Show((kb / 1024 / 1024) + " GB installed in memory");
            ObjectQuery wql = new ObjectQuery("Select * from Win32_OperatingSystem");
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(wql);
            ManagementObjectCollection results = searcher.Get();
            foreach(ManagementObject result in results)
            {
                MessageBox.Show("Total Visible memory " + result["TotalVisibleMemorySize"] + " kb");
                MessageBox.Show("Free physical memory " + result["FreePhysicalMemory"] + " kb");
                MessageBox.Show("Total Virtual memory " + result["TotalVirtualMemorySize"] + " kb");
                MessageBox.Show("Free Virtual memory " + result["FreeVirtualMemory"] + " kb");
            }
        }
    }
}
